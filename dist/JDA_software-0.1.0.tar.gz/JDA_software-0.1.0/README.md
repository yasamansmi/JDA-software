#  JDA Software

A package to forecast the cnt 

## Installation

For installation please first install [Poetry](https://python-poetry.org/docs/). Then make a virtual evironment using poetry. 

```sh
poetry install
```

## Random Forest to the rescue

Tree-based models, such as Decision Trees, Random Forests, and Boosted Trees, typically don't perform well with one-hot encodings with lots of levels. This is because they pick the feature to split on based on how well that splitting the data on that feature will "purify" it.

r"""
Preproceccing and feature engineering steps"""

__author__ = "Yasaman Samiee"
__email__ = "yasaman.msamiee@gmail.com"

import logging
import numpy as np
import pandas

class Preprocessing:
    
    """ Class for performing preprocessing and feature engineering steps. 
    """
    
    def __init__(self, data):
        
        self.data = data
    
    def add_lags(self, lag_n: int = 7) -> pd.DataFrame:
        """Add lags of the target variable to the dataframe and remove the initial null rows

        Parameters
        ----------
        data: pd.DataFrame
            The dataset before performing train/test split

        lag_n: int
            Number of lagged values of target value to be used in forecast as a feature.
        """

        for lag in range(lag_n):
            column_name = f"cnt_lag{lag+1}"
            self.data[column_name] = self.data["cnt"].shift(lag + 1)
        self.data = self.data.iloc[lag_n:]
        
    def omit_columns(self, features :list = ["dteday","instant","casual", "registered"]):
        """Omit columns that are not to be used in the training process. 
        
        Parameters
        ----------
        features : list
            The list of features to be removed. Default has set to be 'casual' and 'registered'
            since they can lead to data leak and instant and dteday since they are redundant."""
        self.data.drop(features,axis=1, inplace = True)
        
    def remove_nulls(self):
        
        """Removnig records with at leat one columns value of null
        """

        null_list = [sum(self.data[i].isna()) *100 / len(self.data) for i in self.data.columns]
        null_percent = all(i < 0.2 for i in null_list)
        if not null_percent: 
            logging.warn("Whatch Out! Too many records are being removed due to remove of nulls")
        self.data = self.data.dropna()
    


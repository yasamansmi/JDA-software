import numpy as np


def make_heatmap(data: pd.DataFrame):
    """Plot the heatmap of variables associations using Seaborn.

    Parameters
    ----------
    data: pd.DataFrame
        The dataset before performing train/test split.
    """
    fig = plt.figure(dpi=400)
    sns.heatmap(
        data.corr(), cmap="coolwarm", annot_kws={"size": 4}, annot=True, fmt=".2f"
    )


def calculate_mape(y_true, y_pred):
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    return mape
